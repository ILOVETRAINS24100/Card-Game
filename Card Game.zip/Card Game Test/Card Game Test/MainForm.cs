﻿using System;
using System.Windows.Forms;

namespace Card_Game_Test
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            // This initializes all the UI components defined in the Designer file
            InitializeComponent();
        }
    }
}
