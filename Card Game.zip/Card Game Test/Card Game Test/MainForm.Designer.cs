﻿namespace Card_Game_Test
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox desc;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.desc = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // desc
            // 
            this.desc.BackColor = System.Drawing.SystemColors.Window;
            this.desc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.desc.Location = new System.Drawing.Point(425, 25);
            this.desc.Multiline = true;
            this.desc.Name = "desc";
            this.desc.ReadOnly = true;
            this.desc.Size = new System.Drawing.Size(325, 500);
            this.desc.TabIndex = 0;
            this.desc.Text = "Lore(spoilers) one day you were sitting on a bench when you fall in to the black " +
    "area. Where a god will call you. Where you have to roll some cards and buy upgra" +
    "des to escape the abyss or you could stay and become the best card roller in th" +
    "e abyss. End of lore. Start of spoilers if you stay in the abyss when the phone" +
    " ask you the phone asks at 1,000,000 over all points you get a prestige like sys" +
    "tem with more upgrade for you that is why it takes so long to get there. End of " +
    "spoilers.\r\n\r\n\r\n\r\n\r\nThis was originally a scratch game, and I am bringing it to ja" +
    "va.";
            this.desc.WordWrap = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.desc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Card Game - A Scratch Port - Original By nomishark";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
