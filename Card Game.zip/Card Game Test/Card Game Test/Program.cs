﻿using System;
using System.Windows.Forms;

namespace Card_Game_Test
{
    internal sealed class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // This tells the application to start by launching your game form
            Application.Run(new MainForm());
        }
    }
}
